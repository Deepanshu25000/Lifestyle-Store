<?php
include 'includes/common.php';
//print_r($_SESSION);
if(!isset($_SESSION['email'])){
	header('location:indexpage.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="settings.css" type="text/css">
    </head>
    <body>
          <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">Cart</span></a></li>
                      <li><a href="settings.php"><span class="glyphicon glyphicon-user">Settings</span></a></li>
                      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">Logout</span></a></li>
                  </ul>
              </div>
                </div>
          </div>
       </nav>-->
	   <?php include 'includes/header.php'; ?>
        <div class="container">
            <div class="row">
                <div class="col-xs-4 col-xs-offset-4">
                    <h1><strong>Change Password</strong></h1>
                    <form method="post" action="settings_script.php">
                        <div class="form-group">
                            <input type="password" name="oldpassword" class="form-control" placeholder="Old Password" required="true">
                        <div><?php if(isset($_GET['old_password_error'])){echo $_GET['old_password_error'];}?></div>
						</div>
                        <div class="form-group">
                            <input type="password" name="newpassword" class="form-control" placeholder="New Password" required="true" pattern=".{6,}">
                          <div><?php if(isset($_GET['new_password_error'])){echo $_GET['new_password_error'];}?></div>
                       </div>
                        <div class="form-group">
                            <input type="password" name="retypenewpassword" class="form-control" placeholder="Re-type New Password" requires="true"><br>
                        <div><?php if(isset($_GET['newpassword_mismatch_error'])){echo $_GET['newpassword_mismatch_error'];}?></div>
						</div>
                        <input type="submit" value="Change" name="submit" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>
    </body>
</html>
