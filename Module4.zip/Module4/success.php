<?php
require 'includes/common.php';
if(!isset($_SESSION['email'])){
	header('location:indexpage.php');
}?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="success.css" type="text/css">
    </head>
    <body>
              <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">Cart</span></a></li>
                      <li><a href="settings.php"><span class="glyphicon glyphicon-user">Settings</span></a></li>
                      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">Logout</span></a></li>
                  </ul>
              </div>
                </div>
          </div>
       </nav>--><?php include 'includes/header.php';?>
        <div class="text-center">
		<?php
		$id=$_SESSION['id'];
		$sql="update user_items set status='confirmed' where user_id='$id'";
		$res=mysqli_query($con,$sql);
		?>
        <h3>Your order is confirmed.</h3><br>
        <h2>Thank You for Shopping with us.<br><br><a href="products.php">Click Here</a>to purchase any other item.</h2><br></div>
		<?php include 'includes/footer.php';?>
         <!--<footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>-->
    </body>
</html>