<?php
require 'includes/common.php';
//echo $_SESSION['email'];
if (isset($_SESSION['email'])) { 
//header('location: products.php'); 
}?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--j Query library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified Java Script -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="indexpage.css" type="text/css">
    </head>
    <body>
        <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="signup.php"><span class="glyphicon glyphicon-user">Signup</span></a></li>
                      <li><a href="login.php"><span class="glyphicon glyphicon-log-in">Login</span></a></li>
                  </ul>
              </div>
                </div>
       </div>
        </nav>-->
                <?php include 'includes/header.php';?>
                <div class="banner_image">
                    <center>
                    <div class="container">
                        
                        <div class="banner-content">
                            <h1>We sell lifestyle.</h1>
                        <p>Flat 40% OFF on premium brands</p><br>
                            <a href="products.php" class="btn btn-danger btn-lg active">Shop Now</a>
                        </div>
                       
                </div>
                    </center>
                </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <a href="#" class="thumbnail"> <img src="images/watch.jpg"> 
                        <div class="caption">
                            <h2>Watches</h2>
                            <p>Original watches from the best brands</p>
                        </div>
                    </a>
                </div> 
                <div class="col-lg-4">
                    <a href="#" class="thumbnail"> <img src="images/nikon.jpg"> 
                        <div class="caption">
                            <h2>Cameras</h2>
                            <p>Choose among the best available in the world.</p>
                        </div>
                    </a>
                </div> 
                <div class="col-lg-4">
                    <a href="#" class="thumbnail"> <img src="images/shoes.jpg"> 
                        <div class="caption">
                             <h2>Shoes</h2>
                      <p>Wide range of products from various brands</p>
                        </div>
                    </a>
                </div> 
                
            </div>
          </div>
        
        
        
        <?php include 'includes/footer.php';?>
       <!-- <footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>-->
      </body>
  </html>