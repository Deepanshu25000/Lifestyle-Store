<?php
require 'includes/common.php';
//print_r($_SESSION);
if(!isset($_SESSION['email'])){
	header('location:login.php');
}?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="settings.css" type="text/css">
    </head>
    <body>
              <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">Cart</span></a></li>
                      <li><a href="settings.php"><span class="glyphicon glyphicon-user">Settings</span></a></li>
                      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">Logout</span></a></li>
                  </ul>
              </div>
                </div>
          </div>
       </nav>-->
	   <?php include 'includes/header.php';
	   $id=$_SESSION['id'];
	   $sql="select * from user_items INNER join items on user_items.item_id=items.pid And status='Added to cart'";
	   $res=mysqli_query($con,$sql);
	   
	   ?>
        <div class="container">
            
                <table class="table table-striped table-bordered">
                    <tr><th><div class="col-xs-2 col-xs-offset-2">
                    Item Number
                        </div></th>
                        <th><div class="col-xs-2">
                    Item Name
                            </div></th>
               <th> <div class="col-xs-2">
                    Price
                   </div></th>
                   <th> <div class="col-xs-2">
                       </div></th></tr>
                    <?php 
					 $total=0;
					 $i=1;
					while($row=mysqli_fetch_array($res))
					{
                      $pid=$row['pid'];
                    echo'<tr><td><div class="col-xs-2 col-xs-offset-2">'.$i++.'</div></td>';
                        echo'<td><div class="col-xs-2">'.$row['name'].'</div></td>';
                        echo'<td><div class="col-xs-2">'.$row['price'].'</div></td>';
                        echo'<td><div class="col-xs-2"><button type="button" class="btn"><a href="cart-remove.php?pid='.$pid.'">Remove From Cart</a></button</div></td></tr>';
           
					$total=$total+$row['price'];}
                    echo'<tr><td><div class="col-xs-2 col-xs-offset-2"></div></td>';
                       echo' <td><div class="col-xs-2">Total='.$total.'</div></td>';
                        echo'<td><div class="col-xs-2">Rs'.$total.'/-</div></td>';
                        echo'<td> <div class="col-xs-2"><a href="success.php" class="btn btn-primary">Confirm Order</a></div></td></tr>';
					?>
       </table>
      
      </div>
			<?php include 'includes/footer.php';?>
         <!--<footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>-->
        </body>
</html>
  