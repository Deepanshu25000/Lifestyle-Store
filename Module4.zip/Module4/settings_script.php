<?php
require 'includes/common.php';
if(!isset($_SESSION['email'])){
	header('location:indexpage.php');
}

$oldpassword=$_POST['oldpassword'];
$newpassword=$_POST['newpassword'];
$retypenewpassword=$_POST['retypenewpassword'];
//print_r($_POST)."<br>";
//print_r($_SESSION);
$oldpassword=md5($oldpassword);
if($oldpassword!=$_SESSION['password']){
	header ('location:settings.php?old_password_error=The old password does not mactch please Try Again');
	
}
if(strlen($newpassword)<6){
	//echo "password should have minimum 6 characters";
	header('location:settings.php?new_password_error=enter correct password');
}
if($newpassword!=$retypenewpassword){
	header('location:settings.php?newpassword_mismatch_error=both your new passwords does not match');
}
$newpassword=md5($newpassword);
$id=$_SESSION['id'];
$sql="update users set password='$newpassword' where id='$id'";
$res=mysqli_query($con,$sql);
echo"your password has been changed successfully.<br>"?>
<a href="login.php" class="btn btn-block btn-primary">Please Log In</a>

