<?php
require 'includes/common.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Login Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="login.css" type="text/css">
    </head>
    <body>
        <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="signup.php"><span class="glyphicon glyphicon-user">Signup</span></a></li>
                      <li><a href="login.php"><span class="glyphicon glyphicon-log-in">Login</span></a></li>
                  </ul>
              </div>
                </div>
       </div>
        </nav>-->
		<?php include 'includes/header.php';?>
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-xs-offset-3">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h1>LOGIN</h1>
                        </div>
                        <div class="panel-body text-warning">
                            Login to make a purchase<br><br>
                            <form method="post" action="login_submit.php">
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" placeholder="Email" required="true" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
									<div><?php if(isset($_GET['email_error'])){echo $_GET['email_error'];}?></div>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control" placeholder="Password" required="true" pattern=".{6,}">
									<div><?php if(isset($_GET['password_error'])){ echo $_GET['password_error'];}?></div>
                                </div>
                                <input type="submit" value="Login" name="submit" class="btn btn-primary">                           
                            </form>
                        </div>
                        <div class="panel-footer">
                            Don't have an account? <a href="signup.php">Register</a> 
                        </div>
                    </div>  
                </div>
            </div>
        </div>
		<?php include 'includes/footer.php'?>
      <!-- <footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>-->
    </body>
  </html>