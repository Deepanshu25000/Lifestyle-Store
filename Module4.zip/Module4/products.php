<?php
require 'includes/common.php';
//print_r($_SESSION);
?> 
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="products.css" type="text/css">
    </head>
    <body>
              <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart">Cart</span></a></li>
                      <li><a href="settings.php"><span class="glyphicon glyphicon-user">Settings</span></a></li>
                      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">Logout</span></a></li>
                  </ul>
              </div>
                </div>
          </div>
       </nav>-->
	   <?php include 'includes/header.php';
	         include 'includes/check-if-added.php';
		 
		 ?>
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our Lifestyle Store!</h1> 
                <p>We have the best cameras, watches and shoes for you. No need to hunt
around, we have all in one place.</p>
            </div>
        </div>
		
        <div class="row text-center">
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/nikon.jpg">
                    <div class="caption">
                        <h3>Nikon</h3>
                        <p>18000</p>
						<?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(1)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=1" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>
						</div>
                       </a>
            </div>
		
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/camera2.jpg">
                    <div class="caption">
                        <h3>Canon</h3>
                        <p>Rs.22000</p>
						<?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(2)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=2" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?> 
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/filmcam.jpg">
                    <div class="caption">
                        <h3>Film Camera</h3>
                        <p>Rs.125000</p>
                        <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(3)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=3" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>
                     </div>
                <a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/webcam.jpg">
                    <div class="caption">
                        <h3>Nest webcam</h3>
                        <p>Rs.10000</p>
                        <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(4)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=4" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>
                    </div>
                </a>
            
        </div>
        <div class="row text-center">
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/watch.jpg">
                    <div class="caption">
                        <h3>Watch</h3>
                        <p>Rs.8000</p>
                        <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(5)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=5" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>
                    </div>
                </a>
            </div> 
             <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/watch4.jpg">
                    <div class="caption">
                        <h3>Chronograph Watch</h3>
                        <p>Rs.10000</p>
                        <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(6)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=6" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>
                    </div>
                </a>
            </div>
             <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/watch2.jpg">
                    <div class="caption">
                        <h3>Black Analog</h3>
                        <p>Rs.5000</p>
                       <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(7)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=7" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?> 
                    </div>
                </a>
            </div>
             <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/watch3.jpg">
                    <div class="caption">
                        <h3>Titan</h3>
                        <p>Rs.15000</p>
                     <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(8)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=8" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>   
                     </div>
                </a>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/shoes.jpg">
                    <div class="caption">
                        <h3>Nike Shoes</h3>
                        <p>Rs.7000</p>
                     <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(9)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=9" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>   
                     </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/shoes1.jpg">
                    <div class="caption">
                        <h3>Loafers</h3>
                        <p>Rs.4000</p>
                     <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(10)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=10" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>   
                     </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/shoes2.jpg">
                    <div class="caption">
                        <h3>Ankle Shoes</h3>
                        <p>Rs.8000</p>
                     <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(11)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=11" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>   
                     </div>
                </a>
            </div>
            <div class="col-md-3 col-sm-6">
                <a href="#" class="thumbnail"><img src="images/shoes3.jpg">
                    <div class="caption">
                        <h3>Black Boot</h3>
                        <p>Rs.10000</p>
                     <?php if (!isset($_SESSION['email'])) { ?> 
						<p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p> 
						<?php } else {
							if (check_if_added_to_cart(12)) {
								echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>'; 
								} else { ?>
								<a href="cart-add.php?pid=12" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a> 
								<?php } } ?>  
                    </div>
                </a>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>
    </body>
  </html>
