<?php
function check_if_added_to_cart($item_id){
	$user_id=$_SESSION['id'];
	$con=mysqli_connect("localhost", "root", "root", "store");
	$sql="SELECT * FROM user_items WHERE item_id='$item_id' AND user_id='$user_id' AND status='Added to cart'";
	$res=mysqli_query($con,$sql);
	if(mysqli_num_rows($res)>0){
		return 1;
	}
	else{
		return 0;
	}
}
?>