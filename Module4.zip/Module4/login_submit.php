<?php
require 'includes/common.php';
$email= $_POST['email'];
$regex_email= "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
if(!preg_match($regex_email,$email)){
	//echo "incoorect mail";
	header('location:login.php?email_error=enter correct email');
}
$password= $_POST['password'];
if(strlen($password)<6){
	//echo "password should have minimum 6 characters";
	header('location:login.php?password_error=enter correct password');
}
$email= mysqli_real_escape_string($con, $_POST['email']);
$password = mysqli_real_escape_string($con, $_POST['password']);
$password=md5($password);
//echo $passwordsec.'<br>';
//echo $password;
$sql="SELECT * from users WHERE email='$email' AND password='$password'";
if(!mysqli_query($con,$sql)){
	die('Error '.mysqli_error($con));
}
$res=mysqli_query($con,$sql);
if(mysqli_num_rows($res)==0)
{
	echo'user with this email and password does not exist';
	exit();
}
$row=mysqli_fetch_array($res);
$_SESSION['email']=$row['email'];
$_SESSION['password']=$row['password'];
$_SESSION['id']=$row['id'];
header('location:products.php');
?>
