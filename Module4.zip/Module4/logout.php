<?php
require 'includes/common.php';
if(!$_SESSION['email']){
header('location:indexpage.php');	
}
session_destroy();
header('location:indexpage.php');
?>