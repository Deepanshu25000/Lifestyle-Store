<?php
require 'includes/common.php';
if (isset($_SESSION['email'])){
//header('location:products.php');
}?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
 <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
        <title>Sign Up Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="signup.css" type="text/css">
    </head>
    <body>
        <!--<nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="row">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a href="#" class="navbar-brand">LifeStyle Store</a>   
              </div>
              <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="signup.php"><span class="glyphicon glyphicon-user">Signup</span></a></li>
                      <li><a href="login.php"><span class="glyphicon glyphicon-log-in">Login</span></a></li>
                  </ul>
              </div>
                </div>
       </nav>-->
	   <?php include 'includes/header.php';?>
        <div class="container">
            <div class="row">
                <div class="col-xs-4 col-xs-offset-4">
                    
                        
                    <h1><strong>SIGN UP</strong></h1>
                        
                    
                           <form method="post" action="signup_script.php">
                               <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" class="form-control" required="true">
                                    </div>
                             <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="text" name="email" class="form-control" required="true" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
									<div><?php if(isset($_GET['email_error'])){echo $_GET['email_error'];}?></div>
                                    </div>
                               <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" name="password" class="form-control" required="true" pattern=".{6,}">
									<div><?php if(isset($_GET['password_error'])){echo $_GET['password_error'];}?></div>
                                    </div>
									<div class="form-group">
                                    <label for="contact">Contact</label>
                                    <input type="number" name="contact" class="form-control">
                                    </div>
                               <div class="form-group">
                                    <label for="city">City</label>
                                    <input type="text" name="city" class="form-control">
                                    </div>
                               <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" class="form-control">
                                    </div>
                               <input type="submit" value="Submit" name="submit" class="btn btn-primary">
                                </form>
                          
                  </div>
               </div>
            </div>
        <!-- <footer class="footer">
            <div class="container">
                   <center>
                    Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000    
                    </center>
            </div>
        </footer>-->
         <?php include 'includes/footer.php';?>
        </body>
  </html>