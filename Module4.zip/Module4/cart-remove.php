<?php
require 'includes/common.php';
print_r($_SESSION);
if(!isset($_SESSION['email'])){
	header('location:indexpage.php');
}
$item_id=$_GET['pid'];
$sql="delete from user_items  where item_id='$item_id'";
$res=mysqli_query($con,$sql);
header('location:cart.php');
?>